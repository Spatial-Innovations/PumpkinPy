# PumpkinPy
### A Python module with utilities for many fields.

## Installation

Run the following to install:

```python
pip install pumpkinpy
```